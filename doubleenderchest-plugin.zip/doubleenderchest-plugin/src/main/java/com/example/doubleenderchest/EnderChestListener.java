package com.example.doubleenderchest;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class EnderChestListener implements Listener {

    private static final int SIZE = 54; // double chest size (vanilla ender chest is 27)

    private final DoubleEnderChestPlugin plugin;

    public EnderChestListener(DoubleEnderChestPlugin plugin) {
        this.plugin = plugin;
    }

    /** Marks our custom inventory so we know to save it (and not a normal chest) on close. */
    private static class DoubleEnderChestHolder implements InventoryHolder {
        final UUID ownerId;
        private Inventory inventory;

        DoubleEnderChestHolder(UUID ownerId) {
            this.ownerId = ownerId;
        }

        void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;
        if (event.getClickedBlock().getType() != Material.ENDER_CHEST) return;
        if (event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return; // avoid firing twice (main + off hand)

        event.setCancelled(true); // stop the vanilla 27-slot ender chest from opening

        Player player = event.getPlayer();
        DoubleEnderChestHolder holder = new DoubleEnderChestHolder(player.getUniqueId());
        Inventory inv = Bukkit.createInventory(holder, SIZE, "Ender Chest");
        holder.setInventory(inv);
        inv.setContents(loadContents(player));
        player.openInventory(inv);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof DoubleEnderChestHolder holder)) return;
        if (!(event.getPlayer() instanceof Player player)) return;
        saveContents(player, event.getInventory().getContents());
    }

    // ---------------------------------------------------------------
    // Storage: one small YAML file per player under plugins/DoubleEnderChest/enderchests/
    // ---------------------------------------------------------------

    private File getPlayerFile(Player player) {
        File dir = new File(plugin.getDataFolder(), "enderchests");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, player.getUniqueId() + ".yml");
    }

    private ItemStack[] loadContents(Player player) {
        ItemStack[] contents = new ItemStack[SIZE];
        File file = getPlayerFile(player);
        if (!file.exists()) return contents;

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("items");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                try {
                    int slot = Integer.parseInt(key);
                    if (slot >= 0 && slot < SIZE) {
                        contents[slot] = section.getItemStack(key);
                    }
                } catch (NumberFormatException ignored) {
                    // skip malformed keys
                }
            }
        }
        return contents;
    }

    private void saveContents(Player player, ItemStack[] contents) {
        YamlConfiguration yaml = new YamlConfiguration();
        for (int i = 0; i < contents.length; i++) {
            if (contents[i] != null) {
                yaml.set("items." + i, contents[i]);
            }
        }
        try {
            yaml.save(getPlayerFile(player));
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save double ender chest for " + player.getName() + ": " + e.getMessage());
        }
    }
}
